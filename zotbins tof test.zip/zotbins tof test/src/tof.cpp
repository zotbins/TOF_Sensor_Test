// Here are the pin connections:
// VIN -> 3V3
// GND -> GND
// SDA -> GPIO 23
// SCL -> GPIO 22
// XSHUT -> connect to positive power, such as a 3V3 power rail on a breadboard
// LEAVE GPIO (INT) unconnected

// Rename this file to main.cpp to test it

#include <Arduino.h>
#include <Wire.h>
#include <VL53L0X.h>
#include <math.h>

static const int SDA_PIN = 23;
static const int SCL_PIN = 22;

static const float BIN_DEPTH_CM = 45.0f;
static const float RIM_OFFSET_CM = 0.0f;

static const uint16_t SAMPLE_INTERVAL_MS = 100;
static const uint16_t SUMMARY_PERIOD_MS   = 3000;
static const int MED_WIN = 5;

VL53L0X tof;

struct Sample { uint32_t t; uint16_t mm; bool valid; };
static const int RING_N = 200;
Sample ringBuf[RING_N];
int rHead = 0, rCount = 0;

uint16_t medBuf[MED_WIN];
int medCount = 0, medPos = 0;

char tag[40] = "";

float cmToFullness(float cm) {
  float eff = BIN_DEPTH_CM - RIM_OFFSET_CM;
  if (eff <= 1.0f) return NAN;
  float f = 100.0f * (eff - cm) / eff;
  if (f < 0) f = 0; if (f > 100) f = 100;
  return f;
}

uint16_t median5_push(uint16_t mm) {
  if (mm == 0 || mm == 0xFFFF) return 0;
  medBuf[medPos] = mm; medPos = (medPos + 1) % MED_WIN;
  if (medCount < MED_WIN) medCount++;
  // copy valid values
  uint16_t tmp[MED_WIN]; int k=0;
  for (int i=0;i<medCount;i++) if (medBuf[i] && medBuf[i]!=0xFFFF) tmp[k++]=medBuf[i];
  if (k==0) return 0;
  // insertion sort small k
  for (int i=1;i<k;i++){ uint16_t key=tmp[i]; int j=i-1; while(j>=0 && tmp[j]>key){tmp[j+1]=tmp[j];--j;} tmp[j+1]=key; }
  return tmp[k/2];
}

void pushSample(uint32_t t, uint16_t mm, bool valid) {
  ringBuf[rHead] = {t, mm, valid};
  rHead = (rHead + 1) % RING_N;
  if (rCount < RING_N) rCount++;
}

struct Stats { int nValid; float avg_cm; float std_cm; float min_cm; float max_cm; float validPct; };
Stats computeStats(uint32_t windowMs) {
  uint32_t now = millis();
  float sum=0, sum2=0; int n=0;
  float minv=INFINITY, maxv=-INFINITY;
  int total=0, valids=0;
  for (int i=0;i<rCount;i++){
    const Sample &s = ringBuf[(rHead - 1 - i + RING_N) % RING_N];
    if (now - s.t > windowMs) break;
    total++;
    if (!s.valid) continue;
    valids++;
    float cm = s.mm / 10.0f;
    sum += cm; sum2 += cm*cm; n++;
    if (cm < minv) minv = cm;
    if (cm > maxv) maxv = cm;
  }
  Stats st{};
  st.nValid = n;
  if (n > 0) {
    st.avg_cm = sum / n;
    float var = (sum2 / n) - (st.avg_cm * st.avg_cm);
    st.std_cm = var > 0 ? sqrtf(var) : 0;
    st.min_cm = minv; st.max_cm = maxv;
  } else {
    st.avg_cm = NAN; st.std_cm = NAN; st.min_cm = NAN; st.max_cm = NAN;
  }
  st.validPct = total ? (100.0f * valids / total) : 0.0f;
  return st;
}

void handleCommands() {
  if (!Serial.available()) return;
  String line = Serial.readStringUntil('\n'); line.trim();
  if (line.startsWith("tag")) {
    if (line.length() > 3) {
      String v = line.substring(3); v.trim();
      v.toCharArray(tag, sizeof(tag));
      Serial.print("\n[set] tag = "); Serial.println(tag);
    } else {
      tag[0] = '\0'; Serial.println("\n[set] tag cleared");
    }
  } else if (line.startsWith("depth")) {
    String v = line.substring(5); v.trim();
    Serial.print("[hint] rebuild with BIN_DEPTH_CM="); Serial.println(v);
  } else {
    Serial.print("[?] unknown cmd: "); Serial.println(line);
  }
}

void setup() {
  Serial.begin(115200);
  delay(150);
  Serial.println("\nVL53L0X terminal tester (type: tag <name>  |  tag to clear)");
  Serial.printf("I2C on SDA=%d SCL=%d\n", SDA_PIN, SCL_PIN);

  Wire.begin(SDA_PIN, SCL_PIN);
  delay(30);

  if (!tof.init()) {
    Serial.println("ERROR: VL53L0X init failed. Check VIN=3V3, GND, SDA, SCL, XSHUT.");
  }
  tof.setTimeout(100);
  tof.startContinuous(33);
}

void loop() {
  static uint32_t tLive=0, tSum=0;

  handleCommands();

  if (millis() - tLive >= SAMPLE_INTERVAL_MS) {
    tLive = millis();
    uint16_t mm = tof.readRangeContinuousMillimeters();
    bool valid = !tof.timeoutOccurred() && mm != 0 && mm != 0xFFFF;

    pushSample(tLive, valid ? mm : 0, valid);

    // real-time line
    uint16_t mmMed = median5_push(valid ? mm : 0);
    float cm = valid ? (mm / 10.0f) : NAN;
    float cmMed = (mmMed ? mmMed/10.0f : NAN);
    float fullness = isnan(cmMed) ? NAN : cmToFullness(cmMed);

    Serial.print("[");
    if (tag[0]) Serial.print(tag); else Serial.print("live");
    Serial.print("] ");

    if (valid) {
      Serial.print("cm=");
      Serial.print(cm, 2);
      Serial.print("  med=");
      if (isnan(cmMed)) Serial.print("--"); else { Serial.print(cmMed, 2); }
      Serial.print("  ");
      Serial.print("full=");
      if (isnan(fullness)) Serial.print("--"); else { Serial.print(fullness, 1); Serial.print("%"); }
    } else {
      Serial.print("timeout/invalid");
    }
    Serial.println();
  }

  // periodic summary
  if (millis() - tSum >= SUMMARY_PERIOD_MS) {
    tSum = millis();
    Stats st = computeStats(SUMMARY_PERIOD_MS);

    Serial.println("------------------------------------------------");
    Serial.print("Summary (last ");
    Serial.print(SUMMARY_PERIOD_MS/1000);
    Serial.print("s");
    if (tag[0]) { Serial.print(", tag="); Serial.print(tag); }
    Serial.println("):");

    Serial.print("  valid samples: "); Serial.println(st.nValid);
    Serial.print("  avg cm:        "); if (isnan(st.avg_cm)) Serial.println("--"); else Serial.println(st.avg_cm, 2);
    Serial.print("  std dev cm:    "); if (isnan(st.std_cm)) Serial.println("--"); else Serial.println(st.std_cm, 2);
    Serial.print("  min/max cm:    ");
    if (isnan(st.min_cm)) Serial.println("-- / --");
    else { Serial.print(st.min_cm, 2); Serial.print(" / "); Serial.println(st.max_cm, 2); }
    Serial.print("  valid ratio:   "); Serial.print(st.validPct, 1); Serial.println("%");
    Serial.println("------------------------------------------------");
  }
}