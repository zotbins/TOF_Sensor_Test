#include <Arduino.h>

// HC-SR04: VCC->5V, GND->GND, TRIG->GPIO4, ECHO->GPIO18 via 10k+10k divider (realistically the divider is optional though if you don't use it for too long)

// Rename this file to main.cpp to test it.

#define TRIG 4
#define ECHO 18

static bool waitFor(int pin, int level, uint32_t us_timeout) {
  uint32_t t0 = micros();
  while ((micros() - t0) < us_timeout) {
    if (digitalRead(pin) == level) return true;
  }
  return false;
}

void setup() {
  Serial.begin(115200);
  delay(150);
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);        // divider drives it
  digitalWrite(TRIG, LOW);

  Serial.println("HC-SR04 diag...");
  // ECHO should idle LOW. If HIGH, wiring/divider is wrong.
  Serial.print("Idle ECHO level = ");
  Serial.println(digitalRead(ECHO));
}

void loop() {
  static const int max_samples = 30;
  static float distances[max_samples];
  static int n_valid = 0;

  // 10–12 us trigger
  digitalWrite(TRIG, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(12);
  digitalWrite(TRIG, LOW);

  // Wait for rising edge (start of echo)
  if (!waitFor(ECHO, HIGH, 60000)) {
    Serial.println("No rise -> no echo. Check TRIG pin, aim/target, or sensor VCC=5V.");
    delay(400);
    return;
  }
  uint32_t t_rise = micros();

  // Wait for falling edge (end of echo)
  if (!waitFor(ECHO, LOW, 60000)) {
    Serial.println("Stuck HIGH -> ECHO not reaching divider GND or GPIO18 not on middle node.");
    delay(400);
    return;
  }
  uint32_t t_fall = micros();

  uint32_t width_us = t_fall - t_rise;          // echo high time
  // Treat near-timeout widths as "out of range"
  if (width_us >= 55000) {                      // ~>9.5m round trip => no return
    Serial.println("Out of range (timeout pulse). Aim at a flat target 15–30 cm away.");
  } else {
    float cm = width_us * 0.0343f * 0.5f;
    Serial.print("pulse "); Serial.print(width_us);
    Serial.print(" us -> "); Serial.print(cm, 2); Serial.println(" cm");

    distances[n_valid++] = cm;
  }

  if (n_valid >= max_samples) {
    // Calculate average
    float sum = 0.0f;
    for (int i = 0; i < max_samples; i++) {
      sum += distances[i];
    }
    float avg_cm = sum / max_samples;

    // Calculate standard deviation
    float variance = 0.0f;
    for (int i = 0; i < max_samples; i++) {
      float diff = distances[i] - avg_cm;
      variance += diff * diff;
    }
    variance /= max_samples;
    float std_cm = sqrt(variance);

    // Find min and max
    float min_cm = distances[0];
    float max_cm = distances[0];
    for (int i = 1; i < max_samples; i++) {
      if (distances[i] < min_cm) min_cm = distances[i];
      if (distances[i] > max_cm) max_cm = distances[i];
    }

    // Print summary
    Serial.println("-----------------------------");
    Serial.println("Summary (last 30 samples):");
    Serial.print("  n_valid: "); Serial.println(max_samples);
    Serial.print("  avg: "); Serial.print(avg_cm, 2); Serial.println(" cm");
    Serial.print("  std: "); Serial.print(std_cm, 2); Serial.println(" cm");
    Serial.print("  min/max: "); Serial.print(min_cm, 2); Serial.print(" / "); Serial.print(max_cm, 2); Serial.println(" cm");
    Serial.println("-----------------------------");

    n_valid = 0; // reset count for next batch
  }

  delay(400);
}